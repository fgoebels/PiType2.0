package org.cytoscape.pitype.PanelVersion_005.internal;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Paint;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;

import org.apache.commons.exec.CommandLine;
import org.apache.commons.exec.DefaultExecutor;
import org.cytoscape.application.CyApplicationManager;
import org.cytoscape.application.swing.CytoPanelComponent;
import org.cytoscape.application.swing.CytoPanelName;
import org.cytoscape.model.CyEdge;
import org.cytoscape.model.CyNetwork;
import org.cytoscape.model.CyRow;
import org.cytoscape.model.CyTable;
import org.cytoscape.model.CyTableUtil;
import org.cytoscape.view.presentation.property.BasicVisualLexicon;
import org.cytoscape.view.vizmap.VisualMappingFunctionFactory;
import org.cytoscape.view.vizmap.VisualMappingManager;
import org.cytoscape.view.vizmap.VisualStyle;
import org.cytoscape.view.vizmap.mappings.BoundaryRangeValues;
import org.cytoscape.view.vizmap.mappings.ContinuousMapping;
import org.cytoscape.view.vizmap.mappings.DiscreteMapping;

/**
 * This class represents the control panel users see in BorderLayout.WEST when
 * loading cytoscape with my app installed. If disable/removed it can be
 * re-added by selecting the menu options associated with this app.
 * 
 * @author mwrana
 *
 */
public class PiTypeControlPanel extends JPanel implements CytoPanelComponent {
	private static final long serialVersionUID = -8809766310401404671L;
	private JButton runButton;
	private RunPanel mainPanel;
	private CyApplicationManager cyApplicationManager;
	private VisualMappingManager vmmServiceRef;
	private CyNetwork activeNetwork;
	private VisualMappingFunctionFactory vmFactoryC;
	private VisualMappingFunctionFactory vmFactoryD;

	/**
	 * This constructor creates the contents of the PiType panel, as well as
	 * determines whether PiType needs to perform "first time install"
	 * 
	 * @param cyApplicationManager
	 *            A Reference to Cytoscape's application manager. This allows
	 *            the program to get references to networks, tables, etc in the
	 *            current cytoscaspe instance.
	 * @param vmmServiceRef
	 *            Reference to cytoscape's visual mapping manager. This is used
	 *            to apply the mappings created to the current visual style, so
	 *            the user sees the created mapping objects.
	 * @param vmFactoryC
	 *            Factory for creating a continuous mapping. This is used to map
	 *            the score to edge width.
	 * @param vmFactoryD
	 *            Factory for creating a discrete mapping. This is used to map
	 *            the classification to edge color.
	 */
	public PiTypeControlPanel(CyApplicationManager cyApplicationManager, VisualMappingManager vmmServiceRef,
			VisualMappingFunctionFactory vmFactoryC, VisualMappingFunctionFactory vmFactoryD) {
		// Setting global variables
		this.cyApplicationManager = cyApplicationManager;
		this.vmmServiceRef = vmmServiceRef;
		this.vmFactoryC = vmFactoryC;
		this.vmFactoryD = vmFactoryD;

		// Creating run button and main panel, which contains dialog options
		mainPanel = new RunPanel();
		runButton = new JButton("Run");

		// Setting layout, adding elements, making visible to user
		this.setLayout(new BorderLayout());
		this.add(mainPanel, BorderLayout.CENTER);
		this.add(runButton, BorderLayout.SOUTH);
		this.setVisible(true);

		/*
		 * Generate the PiTypeUtils folder, and copy the xml file over, if it
		 * does not already exist. Copy the Pitype python script from the jar,
		 * and extract it into the folder. If there is no folder or xml, return
		 * null, telling the program to run the "first time install" script.
		 */
		String location = null;
		try {
			location = PiTypeUtils.generateUtils(this);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		String pythonLocation = location;
		if (pythonLocation == null) {
			// First time -- show first time menu with run button
			OptionsMenu menu = new OptionsMenu(this);
			runButton.addActionListener(e -> menu.setVisible(true));
		} else {
			// Not First Time -- proceed normally
			runButton.addActionListener(e -> runEDT(mainPanel, pythonLocation));
		}
	}

	/**
	 * This method creates the loading bar dialog, and executes a SwingWorker
	 * which performs the rest of PiType
	 * 
	 * @param pythonLocation
	 *            The location of users' python installation
	 */
	void runEDT(JPanel mainPanel, String pythonLocation) {

		// Getting the active network when user presses run button
		this.activeNetwork = cyApplicationManager.getCurrentNetwork();
		JFrame progressBarFrame = new JFrame("PiType progress");

		// Creating progress label and bar
		JLabel progressLabel = new JLabel("Initializing...");
		progressLabel.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 0));
		JProgressBar progressBar = new JProgressBar();
		progressBar.setMinimum(0);
		progressBar.setMaximum(100);
		progressBar.setBorder(BorderFactory.createEmptyBorder(0, 10, 10, 10));

		// Setting JFrame variables and adding elements
		progressBarFrame.setTitle("Automatic Install Progress");
		progressBarFrame.setPreferredSize(new Dimension(400, 90));
		progressBarFrame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		progressBarFrame.setResizable(false);
		progressBarFrame.setLocationRelativeTo(null);
		progressBarFrame.getContentPane().removeAll();
		progressBarFrame.getContentPane().add(progressLabel, BorderLayout.CENTER);
		progressBarFrame.getContentPane().add(progressBar, BorderLayout.SOUTH);
		progressBarFrame.pack();
		progressBarFrame.setVisible(true);

		// executing main task
		PiTypeTask pitypeTask = new PiTypeTask(progressLabel, progressBar, progressBarFrame, pythonLocation);
		pitypeTask.execute();
	}

	/**
	 * This class is where most of the action happens in PiType, using a
	 * SwingWorker to update UI elements so the user can see progress being
	 * made. Arguments are passed to the UI as a string, and the main method
	 * returns void.
	 * 
	 * @author mwrana
	 *
	 */
	private class PiTypeTask extends SwingWorker<Void, String> {

		private JLabel progressText;
		private JFrame progressBarFrame;
		private String pythonLocation;
		private JProgressBar progressBar;

		/**
		 * Constructor which sets global variables
		 * 
		 * @param progressLabel
		 *            The JLabel which is used to update the user
		 * @param progressBarFrame
		 *            The JFrame which contains the progressBar and JLabel that
		 *            send progress updates to the user
		 * @param pythonLocation
		 *            The location of users' python installation, determined
		 *            earlier in the constructor of the superclass
		 */
		private PiTypeTask(JLabel progressLabel, JProgressBar progressBar, JFrame progressBarFrame,
				String pythonLocation) {
			this.progressText = progressLabel;
			this.progressBarFrame = progressBarFrame;
			this.progressBar = progressBar;
			this.pythonLocation = pythonLocation;

		}

		/**
		 * Sets the text of the progress label and percentage finished of
		 * progress barwhen changes are publish()ed
		 */
		@Override
		protected void process(List<String> chunks) {
			for (String chunk : chunks) {
				progressBar.setValue(Integer.valueOf(chunk.substring(0, 2)));
				progressText.setText(chunk.substring(2));
			}
		}

		/**
		 * Gets the Edges from Cytoscape, creates the CommandLine argument to
		 * run the python script, writes the inputs and reads the outputs from
		 * python script, then updates Cytoscape UI with data and adds mapping
		 * functions.
		 */
		@Override
		protected Void doInBackground() throws Exception {

			// Gets user input and handles exceptions from incorrect input
			int edgeSelection = 0;
			String featureSelection = null;
			int taxonomy;
			try {
				edgeSelection = mainPanel.getEdgeSelection();
				featureSelection = mainPanel.getFeatureSelection();
				taxonomy = mainPanel.getTaxonomySelection();
			} catch (ControlPanelSelectionError e) {
				e.showUserErrorMessage();
				return null;
			}

			// gets edgeList from cytoscape
			publish("05Getting EdgeList");
			Thread.sleep(1000);
			List<CyEdge> selectedEdges = CyTableUtil.getEdgesInState(activeNetwork, "selected", true);

			// makes sure at least one edge is being run
			if (edgeSelection == 1 && selectedEdges.size() == 0) {
				new ControlPanelSelectionError("No edges Selected\nSelect at least one edge and re-run")
						.showUserErrorMessage();
				progressBarFrame.dispose();
				return null;
			}
			// if all edges was selected, add all edges to edgeList
			if (edgeSelection == 0)
				selectedEdges.addAll(CyTableUtil.getEdgesInState(activeNetwork, "selected", false));

			// removes duplicate edges based on same source and target nodes
			ArrayList<CyEdge> uniqueEdges = new ArrayList<CyEdge>();
			for (CyEdge edge : selectedEdges)
				if (!PiTypeUtils.checkEdgePresence(edge, uniqueEdges))
					uniqueEdges.add(edge);
			selectedEdges.clear();
			selectedEdges.addAll(uniqueEdges);
			Thread.sleep(1000);

			// writing the node data to a text file
			publish("10Writing Node Data to File");
			Thread.sleep(1000);
			PiTypeUtils.writeNodeData(activeNetwork, selectedEdges);
			Thread.sleep(1000);

			// Command Line argument to pitype
			// python_location,python_file,features,taxID,input_file,output_file
			publish("15Generating Command Line");
			Thread.sleep(1000);
			CommandLine startPitype = new CommandLine(pythonLocation);
			startPitype.addArgument(PiTypeUtils.UTIL_FOLDER + File.separator + "Pitype2.py");
			startPitype.addArgument(featureSelection);
			startPitype.addArgument(String.valueOf(taxonomy));
			startPitype.addArgument(PiTypeUtils.UTIL_FOLDER + File.separator + "input.txt");
			startPitype.addArgument(PiTypeUtils.UTIL_FOLDER + File.separator + "output.txt");

			// execute pitype...this may take awhile
			publish("20Classifying... (see manual for time estimates)");
			DefaultExecutor executor = new DefaultExecutor();
			executor.execute(startPitype);

			// adds 2 columns to EdgeTable
			publish("80Updating Table");
			Thread.sleep(1000);
			CyTable edgeTable = activeNetwork.getDefaultEdgeTable();
			if (edgeTable.getColumn("pitype_score") != null)
				edgeTable.deleteColumn("pitype_score");
			if (edgeTable.getColumn("pitype_classification") != null)
				edgeTable.deleteColumn("pitype_classification");
			edgeTable.createColumn("pitype_score", Double.class, true, 0.0);
			edgeTable.createColumn("pitype_classification", String.class, true, "--");
			
			
			// reads output python text file and fills columns with
			// classification scores
			publish("90Updating Table");
			List<CyRow> edgeRows = edgeTable.getAllRows();
			BufferedReader buff = new BufferedReader(
					new FileReader(PiTypeUtils.UTIL_FOLDER + File.separator + "output.txt"));
			String line;
			while ((line = buff.readLine()) != null) {
				String[] lineData = line.split("\t");
				for (CyRow edge : edgeRows) {
					String edgeName = edge.get("shared name", String.class);
					if (edgeName.contains(lineData[0]) && edgeName.contains(lineData[1])) {
						String classification;
						if (Integer.valueOf(lineData[2]) == 0)
							classification = "nob";
						else
							classification = "ob";
						edge.set("pitype_classification", classification);
						edge.set("pitype_score", Double.valueOf(lineData[3]));

					}
				}
			}
			buff.close();

			/*
			 * Create mappings and add them to the current visual style, needs
			 * to be done in swing thread, so invoke and wait before closing
			 * progress dialog
			 */
			SwingUtilities.invokeAndWait(new Runnable() {
				@Override
				public void run() {
					// continuous mapping
					ContinuousMapping<Double, Double> cMapping = (ContinuousMapping<Double, Double>) vmFactoryC
							.createVisualMappingFunction("pitype_score", Double.class, BasicVisualLexicon.EDGE_WIDTH);
					// discrete mapping
					DiscreteMapping<String, Paint> dMapping = (DiscreteMapping<String, Paint>) vmFactoryD
							.createVisualMappingFunction("pitype_classification", String.class,
									BasicVisualLexicon.EDGE_STROKE_UNSELECTED_PAINT);

					// add points and value associations so the mappings are
					// apropriate
					dMapping.putMapValue("nob", Color.BLUE);
					dMapping.putMapValue("ob", Color.GREEN);

					BoundaryRangeValues<Double> brv1 = new BoundaryRangeValues<Double>(5.0, 5.0, 5.0);
					BoundaryRangeValues<Double> brv2 = new BoundaryRangeValues<Double>(0.0, 0.0, 0.0);
					cMapping.addPoint(0.0, brv1);
					cMapping.addPoint(0.5, brv2);
					cMapping.addPoint(1.0, brv1);

					// apply mappings to current visual style
					VisualStyle vs = vmmServiceRef.getCurrentVisualStyle();
					vs.addVisualMappingFunction(cMapping);
					vs.addVisualMappingFunction(dMapping);
					vmmServiceRef.setCurrentVisualStyle(vs);
				}
			});

			publish("95Done...Finalizing");
			Thread.sleep(1000);

			return null;
		}

		/**
		 * Handles exceptions and cleanup
		 */
		@Override
		public void done() {
			try {
				this.get();
			} catch (Exception e) {
				progressBarFrame.setVisible(false);
				JOptionPane.showMessageDialog(null, e.getMessage(), "PiType Error", JOptionPane.ERROR_MESSAGE);
				progressBarFrame.setVisible(true);
				e.printStackTrace();
				return;
			} finally {
				progressBarFrame.dispose();
			}

		}

	}

	/**
	 * Accessor method
	 * 
	 * @return a reference to the run button at the bottom of this panel
	 */
	JButton getRunButton() {
		return this.runButton;
	}

	/**
	 * Accessor method
	 * 
	 * @return a reference to the JPanel containing all the user input
	 */
	RunPanel getRunPanel() {
		return this.mainPanel;
	}
	
	/**
	 * Accessor method for cytoscape
	 */
	@Override
	public Component getComponent() {
		return this;
	}
	
	/**
	 * Accessor method for cytoscape
	 */
	@Override
	public CytoPanelName getCytoPanelName() {
		return CytoPanelName.WEST;
	}
	
	/**
	 * Accessor method for cytoscape
	 */
	@Override
	public String getTitle() {
		return "PiType";
	}
	/**
	 * Accessor method for cytoscape
	 */
	@Override
	public Icon getIcon() {
		return null;
	}
}
