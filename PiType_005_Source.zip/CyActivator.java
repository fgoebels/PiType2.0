package org.cytoscape.pitype.PanelVersion_005.internal;

import java.util.Properties;

import org.cytoscape.application.CyApplicationManager;
import org.cytoscape.application.swing.CyAction;
import org.cytoscape.application.swing.CySwingApplication;
import org.cytoscape.application.swing.CytoPanelComponent;
import org.cytoscape.service.util.AbstractCyActivator;
import org.cytoscape.view.vizmap.VisualMappingFunctionFactory;
import org.cytoscape.view.vizmap.VisualMappingManager;
import org.osgi.framework.BundleContext;

public class CyActivator extends AbstractCyActivator {
	/**
	 * Blank Constructor
	 */
	public CyActivator() {
		super();
	}

	/**
	 * Starts the application and gets references to cytoscape elements
	 */
	@Override
	public void start(BundleContext context) throws Exception {
		// Creating Factories
		VisualMappingFunctionFactory vmFactoryC = getService(context, VisualMappingFunctionFactory.class,
				"(mapping.type=continuous)");
		VisualMappingFunctionFactory vmFactoryD = getService(context, VisualMappingFunctionFactory.class,
				"(mapping.type=discrete)");
		// Creating Managers
		CyApplicationManager cyApplicationManager = getService(context, CyApplicationManager.class);
		CySwingApplication cytoscapeDesktopService = getService(context, CySwingApplication.class);
		VisualMappingManager vmmServiceRef = getService(context, VisualMappingManager.class);
		// Creating Control Panel, and Menu Item Action Objects
		PiTypeControlPanel controlPanel = new PiTypeControlPanel(cyApplicationManager, vmmServiceRef, vmFactoryC,
				vmFactoryD);
		ControlPanelAction controlPanelAction = new ControlPanelAction(cytoscapeDesktopService, controlPanel);
		// Registering Service
		registerService(context, controlPanel, CytoPanelComponent.class, new Properties());
		registerService(context, controlPanelAction, CyAction.class, new Properties());
	}

}
