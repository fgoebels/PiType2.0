package org.cytoscape.pitype.PanelVersion_005.internal;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.HeadlessException;
import java.awt.event.ActionListener;
import java.io.File;
import java.net.URL;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JTextArea;
import javax.swing.SwingWorker;

import org.apache.commons.exec.CommandLine;
import org.apache.commons.exec.DefaultExecutor;
import org.apache.commons.io.FileUtils;

/**
 * This class represents the menu which appears if the user has never installed
 * PiType before. It handles the first time installation and progress meter if
 * automatic is chosen, and the text input if custom is chosen
 * 
 * @author mwrana
 *
 */
class OptionsMenu extends JFrame {

	// Creating text labels which display information to the user
	private static final long serialVersionUID = -7281194053208476620L;

	private static final JLabel dialogLabel1 = new JLabel(
			"PiType has detected this is your first time running the App, and requires some setup.");
	private static final JLabel dialogLabel2 = new JLabel(
			"In order to run correctly, PiType needs to Install Miniconda with Python 2.7 onto your machine.");
	private static final JLabel dialogLabel3 = new JLabel(
			"If you would like to handle the download and installation automatically, select the 'Automatic' option (approximately 1.5 GB).");
	private static final JLabel dialogLabel4 = new JLabel(
			"If you already have Miniconda/Anaconda downloaded, or would like to use your own installation of python, select the 'Custom' option.");

	private static final JLabel customDialogLabel1 = new JLabel(
			"The PiType Classifier was built using Python 2.7 and 3 external libraries:");
	private static final JLabel customDialogLabel2 = new JLabel("NumPy, SciPy, and scikit-learn");
	private static final JLabel customDialogLabel3 = new JLabel(
			"Ensure you have an installation of python 2.7 with these modules.");
	private static final JLabel customDialogLabel4 = new JLabel(
			"Type the location of a python installation which meets these requirements below (press continue when done).");
	private final JTextArea customDialogInputArea = new JTextArea();

	private PiTypeControlPanel controlPanel;

	/**
	 * @param controlPanel
	 *            a reference to the control panel object from which the 'run'
	 *            button was pressed
	 * @throws HeadlessException
	 *             if the JFrame loses its reference or something (happens when
	 *             cytoscape quits)
	 */
	OptionsMenu(PiTypeControlPanel controlPanel) throws HeadlessException {
		super();
		this.controlPanel = controlPanel;
		createOriginalGUI();
	}

	/**
	 * This method shows the progress bar gui after "automatic install" is
	 * pressed, and executes the swingworker which performs the task
	 */
	private void automaticInstall() {
		// creating loading bar GUI
		ProgressFrameReturn frameData = createAndShowAutomaticGUI();

		// Creating an instance of the installation task, and executing it
		AutomaticInstallTask automaticInstallTask = new AutomaticInstallTask(frameData.progressLabel,
				frameData.progressBar, this);
		automaticInstallTask.execute();
	}

	/**
	 * This method shows the progress bar gui after "custom install" is pressed,
	 * and executes the swingworker which performs the task
	 */
	private void customInstall() {
		// creating loading bar GUI
		ProgressFrameReturn frameData = createAndShowAutomaticGUI();
		setTitle("Custom Verification Progress");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setPreferredSize(new Dimension(450, 90));

		// Creating an instance of the installation task, and executing it
		CustomInstallTask customInstallTask = new CustomInstallTask(frameData.progressLabel, frameData.progressBar,
				this, customDialogInputArea.getText().trim());
		customInstallTask.execute();
	}

	/**
	 * This method changes the current JFrame, so is used to show the user
	 * progress made after pressing "automatic install"
	 * 
	 * @return a reference to the jlabel and jprogressbar within the jframe
	 */
	private ProgressFrameReturn createAndShowAutomaticGUI() {
		// creates a JLabel and progress bar, where the label gives text updates
		// and the bar visually shows progress
		JLabel progressLabel = new JLabel("Initializing...");
		progressLabel.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 0));
		JProgressBar progressBar = new JProgressBar();
		progressBar.setMinimum(0);
		progressBar.setMaximum(100);
		progressBar.setBorder(BorderFactory.createEmptyBorder(0, 10, 10, 10));

		// clearing old elements and adding loading bar stuff
		setTitle("Automatic Install Progress");
		setPreferredSize(new Dimension(400, 90));
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		getContentPane().removeAll();
		getContentPane().add(progressLabel, BorderLayout.CENTER);
		getContentPane().add(progressBar, BorderLayout.SOUTH);
		pack();
		revalidate();
		repaint();

		return new ProgressFrameReturn(progressLabel, progressBar);
	}

	/**
	 * This method displays the text input and information menu when the user
	 * presses "custom install"
	 */
	private void createAndShowCustomGUI() {
		// Creating text elements to be added to GUI
		JPanel textPanel = new JPanel();
		textPanel.setLayout(new BoxLayout(textPanel, BoxLayout.Y_AXIS));
		customDialogLabel1.setAlignmentX(Component.CENTER_ALIGNMENT);
		customDialogLabel1.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
		textPanel.add(customDialogLabel1);
		customDialogLabel2.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
		customDialogLabel2.setAlignmentX(Component.CENTER_ALIGNMENT);
		customDialogLabel2.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 13));
		textPanel.add(customDialogLabel2);
		customDialogLabel3.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
		customDialogLabel3.setAlignmentX(Component.CENTER_ALIGNMENT);
		textPanel.add(customDialogLabel3);
		customDialogLabel4.setAlignmentX(Component.CENTER_ALIGNMENT);
		customDialogLabel4.setAlignmentX(Component.CENTER_ALIGNMENT);
		textPanel.add(customDialogLabel4);
		textPanel.add(Box.createVerticalStrut(12));
		textPanel.add(customDialogInputArea);
		customDialogInputArea.setLineWrap(true);
		customDialogInputArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));

		// Creating button elements to be added to GUI
		JPanel buttonPanel = new JPanel();
		JButton automaticButton = new JButton("Use Automatic Instead");
		buttonPanel.add(automaticButton);
		automaticButton.addActionListener(e -> automaticInstall());
		JButton continueButton = new JButton("Continue with Custom");
		buttonPanel.add(continueButton);
		continueButton.addActionListener(e -> customInstall());
		this.add(buttonPanel, BorderLayout.SOUTH);

		// Adding text and buttons, as well as updating JFrame variables
		setTitle("Custom Install Information");
		setPreferredSize(new Dimension(650, 240));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().removeAll();
		getContentPane().add(textPanel, BorderLayout.CENTER);
		getContentPane().add(buttonPanel, BorderLayout.SOUTH);
		pack();
		revalidate();
		repaint();

	}

	/**
	 * The main GUI window which gives the user a choice between "automatic" and
	 * "manual" install
	 */
	private void createOriginalGUI() {
		// Creating text elements to be added to GUI
		JPanel mainOptionsPanel = new JPanel();
		mainOptionsPanel.setLayout(new BoxLayout(mainOptionsPanel, BoxLayout.PAGE_AXIS));
		dialogLabel1.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		dialogLabel1.setAlignmentX(Component.CENTER_ALIGNMENT);
		dialogLabel1.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		mainOptionsPanel.add(dialogLabel1);
		dialogLabel2.setAlignmentX(Component.CENTER_ALIGNMENT);
		dialogLabel2.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		mainOptionsPanel.add(dialogLabel2);
		dialogLabel3.setAlignmentX(Component.CENTER_ALIGNMENT);
		mainOptionsPanel.add(dialogLabel3);
		dialogLabel4.setAlignmentX(Component.CENTER_ALIGNMENT);
		dialogLabel4.setBorder(BorderFactory.createEmptyBorder(0, 10, 10, 10));
		mainOptionsPanel.add(dialogLabel4);

		// Creating button elements to be added to GUI
		JPanel mainButtonsPanel = new JPanel();
		mainButtonsPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));
		JButton automaticInstallButton = new JButton("Automatic (Recommended)");
		JButton customInstallButton = new JButton("Custom");
		mainButtonsPanel.add(customInstallButton);
		customInstallButton.addActionListener(e -> createAndShowCustomGUI());
		mainButtonsPanel.add(automaticInstallButton);
		automaticInstallButton.addActionListener(e -> automaticInstall());

		// Adding text and buttons, as well as updating JFrame variables
		this.getContentPane().removeAll();
		setTitle("PiType First Time Setup");
		setPreferredSize(new Dimension(900, 200));
		setLocationRelativeTo(null);
		setResizable(false);
		getContentPane().setLayout(new BorderLayout());
		getContentPane().add(mainOptionsPanel, BorderLayout.CENTER);
		getContentPane().add(mainButtonsPanel, BorderLayout.SOUTH);
		setAlwaysOnTop(true);
		pack();
		revalidate();
		repaint();
	}

	/**
	 * This class is a SwingWorker, which means it is designed to work in the
	 * background after the user presses a button. Using this class allows me to
	 * update the user on install progress without freezing the UI, while
	 * downloading and installing various things on users' computer
	 * 
	 * @author mwrana
	 *
	 */
	private class AutomaticInstallTask extends SwingWorker<Void, String> {

		private JLabel progressText;
		private OptionsMenu menu;
		private String pythonLocation;
		private JProgressBar progressBar;

		private AutomaticInstallTask(JLabel progressText, JProgressBar progressBar, OptionsMenu menu) {
			// global variables
			this.progressText = progressText;
			this.progressBar = progressBar;
			this.menu = menu;

		}

		/**
		 * Sets the text of the progress label and percentage finished of
		 * progress barwhen changes are publish()ed
		 */
		@Override
		protected void process(List<String> chunks) {
			// Update GUI label and progress bar
			for (String chunk : chunks) {
				progressBar.setValue(Integer.valueOf(chunk.substring(0, 2)));
				progressText.setText(chunk.substring(2));
			}
		}

		/**
		 * This is the 'main' method of AutomaticInstallTask and where most of
		 * the action happens, a little bit of setup and finishing is located
		 * elsewhere
		 */
		@Override
		protected Void doInBackground() throws Exception {

			// Creating CommandLine arguments to be used based on OS version
			File downloadDestination = PiTypeUtils.getDownloadDestination();
			DefaultExecutor executor = new DefaultExecutor();
			CommandLine installCommand = PiTypeUtils.getInstallCommand(downloadDestination);

			// OS not recognized
			if (installCommand == null)
				throw new Exception("PiType Only Supports Windows, MacOS, and Linux");
			CommandLine installModulesCommand = PiTypeUtils.getModulesCommand(downloadDestination);

			// 0%
			// getting download URL from miniconda
			publish("00Initilization Complete ... Beginning Download");
			URL downloadURL = PiTypeUtils.getOSDownload();

			// 1%
			// downloading miniconda install script
			publish("01Downloading Miniconda...");
			FileUtils.copyURLToFile(downloadURL, downloadDestination);

			// 6%
			// installing basic miniconda package
			publish("06Installing Miniconda...");
			executor.execute(installCommand);

			// 18%
			// installing scikit-learn (for pitype to work)
			publish("18Downloading & Installing Additional Libraries...");
			executor.execute(installModulesCommand);

			// 98%
			// deleting extra files/cleanup
			publish("95Installation Complete... Finalizing");
			downloadDestination.delete();
			Thread.sleep(1000);

			// update global variable for pythonLocation and XML file
			this.pythonLocation = PiTypeUtils.CONDA_FOLDER + File.separator + "bin" + File.separator + "python";
			PiTypeUtils.updateXML(this, pythonLocation);
			return null;
		}

		/**
		 * 
		 * Handles exceptions and cleanup
		 * 
		 * Once the Install has completed, change the run button action
		 * listener, so it now runs PiType normally, instead of displaying this
		 * dialog, then close this dialog
		 */
		@Override
		public void done() {
			try {
				get();
			} catch (Exception e) {
				menu.setVisible(false);
				JOptionPane.showMessageDialog(null, e.getMessage(), "PiType Error", JOptionPane.ERROR_MESSAGE);
				menu.setVisible(true);
				return;
			} finally {
				createOriginalGUI();
			}
			JButton runButton = controlPanel.getRunButton();
			for (ActionListener al : runButton.getActionListeners())
				runButton.removeActionListener(al);
			runButton.addActionListener(e -> controlPanel.runEDT(controlPanel.getRunPanel(), pythonLocation));
			menu.dispose();
		}

	}

	/**
	 * This task is a swingworker, and performs the custom install operations,
	 * while keeping the user updated as to any progress made.
	 * 
	 * @author mwrana
	 *
	 */
	private class CustomInstallTask extends SwingWorker<Void, String> {

		private OptionsMenu menu;
		private String givenLocation;
		private JLabel progressText;
		private JProgressBar progressBar;

		private CustomInstallTask(JLabel progressText, JProgressBar progressBar, OptionsMenu menu,
				String givenLocation) {
			this.menu = menu;
			this.givenLocation = givenLocation;
			this.progressText = progressText;
			this.progressBar = progressBar;
		}

		/**
		 * Sets the text of the progress label and percentage finished of
		 * progress barwhen changes are publish()ed
		 */
		@Override
		protected void process(List<String> chunks) {
			for (String chunk : chunks) {
				progressBar.setValue(Integer.valueOf(chunk.substring(0, 2)));
				progressText.setText(chunk.substring(2));
			}
		}

		/**
		 * This is where all the action happends, and the python installation
		 * selected by the user is verified, as well as updates are sent to the
		 * UI
		 */
		@Override
		protected Void doInBackground() throws Exception {

			// making sure the file exists and is actually a file not a
			// directory
			this.publish("05Ensuring File Has Correct Type");

			File locationFile = new File(givenLocation);
			if (!locationFile.exists())
				throw new Exception("The file you specified does not exist");
			if (locationFile.isDirectory())
				throw new Exception(
						"The file you specified is a directory\n please select the python execution script");

			// Copy the tester python script out of the jar
			File customTester = new File(PiTypeUtils.UTIL_FOLDER + File.separator + "customTester.py");
			FileUtils.copyURLToFile(getClass().getClassLoader().getResource("customTester.py"), customTester);
			DefaultExecutor executor = new DefaultExecutor();
			// create command line argument to run test script
			CommandLine runScript = new CommandLine(givenLocation);
			runScript.addArgument(customTester.getAbsolutePath());

			this.publish("20Ensuring correct python version and modules");
			Thread.sleep(1000);

			// run the test script and throw exception if the program does
			try {
				executor.execute(runScript);
			} catch (Exception e) {
				System.out.println(e.getMessage());
				throw new Exception(
						"It Appears Either your python version is NOT 2.7, or you are missing some modules.");
			} finally {
				customTester.delete();
			}

			// update the XML, as the given installation will work
			// 60%
			this.publish("60Updating Configuration Files");
			Thread.sleep(1000);
			PiTypeUtils.updateXML(this, givenLocation);

			this.publish("95Done...Finalizing");
			Thread.sleep(1000);
			// 95%

			return null;
		}
		
		/**
		 * 
		 * Handles exceptions and cleanup
		 * 
		 * Once the Install has completed, change the run button action
		 * listener, so it now runs PiType normally, instead of displaying this
		 * dialog, then close this dialog
		 */
		@Override
		public void done() {
			try {
				get();
			} catch (Exception e) {
				menu.setVisible(false);
				JOptionPane.showMessageDialog(null, e.getMessage(), "PiType Custom Install Error",
						JOptionPane.ERROR_MESSAGE);
				menu.setVisible(true);
				return;
			} finally {
				menu.createAndShowCustomGUI();
			}
			menu.setVisible(false);
			JOptionPane.showMessageDialog(null, "Custom Installation Verified, Press OK to Complete.",
					"PiType Confirmation", JOptionPane.INFORMATION_MESSAGE);
			JButton runButton = controlPanel.getRunButton();
			for (ActionListener al : runButton.getActionListeners())
				runButton.removeActionListener(al);
			runButton.addActionListener(e -> controlPanel.runEDT(controlPanel.getRunPanel(), givenLocation));
			menu.dispose();
		}

	}

	/**
	 * Inner Class used to return a JLabel and JFrame in the same method
	 * 
	 * @author mwrana
	 *
	 */
	private class ProgressFrameReturn {
		public JLabel progressLabel;
		public JProgressBar progressBar;

		ProgressFrameReturn(JLabel progressLabel, JProgressBar progressBar) {
			this.progressLabel = progressLabel;
			this.progressBar = progressBar;
		}
	}

}
