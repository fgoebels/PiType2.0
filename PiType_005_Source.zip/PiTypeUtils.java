package org.cytoscape.pitype.PanelVersion_005.internal;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import javax.swing.JOptionPane;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.exec.CommandLine;
import org.apache.commons.io.FileUtils;
import org.cytoscape.model.CyEdge;
import org.cytoscape.model.CyNetwork;
import org.cytoscape.model.CyNode;
import org.w3c.dom.Document;

/**
 * static utility class for PiType, in order to keep the code from getting too
 * messy
 */
class PiTypeUtils {

	public static final String UTIL_FOLDER = System.getProperty("user.home") + File.separator + "PiTypeUtils";
	public static final String CONDA_FOLDER = UTIL_FOLDER + File.separator + "Miniconda_PiType";
	public static final OSVersion version = getOSVersion();

	/**
	 * Finds the Utils folder and fills it with stuff if need be, otherwiser
	 * reads the xml if it has already been created
	 * 
	 * @param classRef
	 *            a reference to an object contained within the jar
	 * @return the location of a python installaion, if this is not the first
	 *         time, null otherwise
	 * @throws Exception
	 *             if there is an error reading or extracting the zip file and
	 *             xml
	 */
	static String generateUtils(Object classRef) throws Exception {
		File utilFolderFile = new File(UTIL_FOLDER);
		File xmlFile = new File(UTIL_FOLDER + File.separator + "installConfig.xml");
		File minicondaInstall = new File(CONDA_FOLDER);

		if (!utilFolderFile.exists() || FileUtils.sizeOfDirectory(utilFolderFile) < 10000) {
			utilFolderFile.mkdirs();
			copyPythonFiles(classRef);
			FileUtils.copyURLToFile(classRef.getClass().getClassLoader().getResource("installConfig.xml"), xmlFile);
		}
		if (!xmlFile.exists()) {
			FileUtils.copyURLToFile(classRef.getClass().getClassLoader().getResource("installConfig.xml"), xmlFile);
		}

		String pythonInstall = readXML(xmlFile);

		if (pythonInstall == null && minicondaInstall.exists())
			FileUtils.deleteDirectory(minicondaInstall);

		return pythonInstall;

	}

	/**
	 * reads a custom xml file which is known to exist, and determines if it is
	 * the first time PiType has been run
	 * 
	 * @param xml
	 *            file which represents the xml file to be read
	 * @return either the location of a python install or none, if the xml is
	 *         new
	 * @throws Exception
	 *             if there is an error reading the XML
	 */
	private static String readXML(File xml) throws Exception {

		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
		Document doc = docBuilder.parse(xml);

		if (Boolean.parseBoolean(doc.getElementsByTagName("Installed").item(0).getTextContent()))
			return doc.getElementsByTagName("Directory").item(0).getTextContent();
		else
			return null;
	}

	static void updateXML(Object classRef, String pythonLocation) throws Exception {

		File xml = new File(UTIL_FOLDER + File.separator + "installConfig.xml");
		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
		Document doc = docBuilder.parse(xml);

		doc.getElementsByTagName("Installed").item(0).setTextContent("true");
		doc.getElementsByTagName("Directory").item(0).setTextContent(pythonLocation);

		TransformerFactory transFactory = TransformerFactory.newInstance();

		Transformer trans = transFactory.newTransformer();
		DOMSource source = new DOMSource(doc);
		StreamResult result = new StreamResult(xml);
		trans.transform(source, result);
	}

	/**
	 * Maps a CyNode which is part of a list to its degree, which is the number
	 * of connecting nodes. Unnecessarily complicated since if there are
	 * multiple edges connecting the same 2 nodes, each edge counts as one
	 * adjacent node by cytoscape, but PiTyoe would count it as a single
	 * adjacent node
	 * 
	 * @param activeNetwork
	 *            a CyNetwork object which represents the network containing the
	 *            edges to be analyzeds
	 * @param selectedEdges
	 *            a list of CyEdges to be analyzed
	 * @param nodeType
	 *            either 0 for source nodes, or 1 for target nodes, since both
	 *            cannot be calculated simeltaneously, due to the limitations of
	 *            Java return types
	 * @return a LinkedHashMap of each Node mapped to its degree (excluding
	 *         repeat edges)
	 */
	static LinkedHashMap<CyNode, Integer> getNodeData(CyNetwork activeNetwork, List<CyEdge> selectedEdges,
			int nodeType) {
		LinkedHashMap<CyNode, Integer> nodes = new LinkedHashMap<CyNode, Integer>();

		// Check whether analysis is for source or target nodes
		if (nodeType == 0)
			/*
			 * Get the source node for each edge in the list, get the number of
			 * adjacent edges, and put this into the nodes HashMap
			 */
			for (CyEdge edge : selectedEdges) {
				CyNode n = edge.getSource();
				List<CyNode> nodeList = activeNetwork.getNeighborList(n, CyEdge.Type.ANY);
				Set<CyNode> nodeSet = new HashSet<>();
				nodeSet.addAll(nodeList);
				nodes.put(n, nodeSet.size());
			}
		else
			// Same as above, for target nodes
			for (CyEdge edge : selectedEdges) {
				CyNode n = edge.getTarget();
				List<CyNode> nodeList = activeNetwork.getNeighborList(n, CyEdge.Type.ANY);
				Set<CyNode> nodeSet = new HashSet<>();
				nodeSet.addAll(nodeList);
				nodes.put(n, nodeSet.size());
			}
		return nodes;
	}

	/**
	 * This methods write the node data gathered from the above method
	 * getNodeData to a text file, which is then read by the PiType python
	 * script
	 * 
	 * @param activeNetwork
	 *            the CyNetwork which contains the source and target nodes in
	 *            the hasmap
	 * @param sourceNodes
	 *            A LinkedHashMap containing each source node and its degree
	 * @param targetNodes
	 *            a LinkedHashMap containing each target node and its degree
	 * @throws IOException
	 *             if an error occurs while writing the file, throws error
	 */
	static void writeNodeData(CyNetwork activeNetwork, List<CyEdge> edgeList) throws IOException {

		// Creating (and establishing) Files & Iterators
		File writeLocation = new File(
				System.getProperty("user.home") + File.separator + "PiTypeUtils" + File.separator + "input.txt");
		Iterator<CyEdge> edgeIterator = edgeList.iterator();
		BufferedWriter fileWriter = null;

		try {
			// Assign the BufferedWriter to create the text file
			fileWriter = new BufferedWriter(new FileWriter(writeLocation));

			// source and target HashMaps have the same length, this works
			while (edgeIterator.hasNext()) {
				CyEdge edge = edgeIterator.next();
				CyNode source = edge.getSource();
				CyNode target = edge.getTarget();

				String sourceName = activeNetwork.getRow(source).get(CyNetwork.NAME, String.class);
				String targetName = activeNetwork.getRow(target).get(CyNetwork.NAME, String.class);

				fileWriter.write(sourceName + "\t" + targetName);
				fileWriter.newLine();
			}
		} catch (IOException ioe) {
			// send the error back to main runtime, so it doesnt attempt to
			// continue
			throw new IOException("Error occured while trying to write a file to the following location: "
					+ writeLocation.getAbsolutePath());
		} finally {
			// cleanup after sending error up callstack
			try {
				fileWriter.close();
			} catch (IOException ioe) {
				JOptionPane.showMessageDialog(null, "Unknown Error Occured:\n" + ioe.getMessage(), "PiType Error",
						JOptionPane.ERROR_MESSAGE);
				writeLocation.delete();
			}
		}

	}

	/**
	 * different install commands are required on different operating systems...
	 * 
	 * @param downloadDest
	 *            the location of the script to be executed
	 * @return the install command appropriate to the current OS
	 */
	static CommandLine getInstallCommand(File downloadDest) {

		CommandLine installMiniCommandUnix = new CommandLine("/bin/bash");
		installMiniCommandUnix.addArgument(downloadDest.getAbsolutePath());
		installMiniCommandUnix.addArgument("-b");
		installMiniCommandUnix.addArgument("-p");
		installMiniCommandUnix.addArgument(CONDA_FOLDER);

		CommandLine installMiniCommandWindows = new CommandLine(downloadDest.getAbsolutePath());
		installMiniCommandWindows.addArgument("/S");
		installMiniCommandWindows.addArgument("/D=" + CONDA_FOLDER);

		switch (version) {
		case WINDOWS32:
		case WINDOWS64:
			return installMiniCommandWindows;
		case MacOS:
		case LINUX32:
		case LINUX64:
			return installMiniCommandUnix;
		case UNKNOWN:
			return null;
		}

		return null;
	}

	/**
	 * different install commands are required on different operating systems...
	 * 
	 * @param downloadDest
	 *            the location of the script to be executed
	 * @return the install command appropriate to the current OS
	 */
	static CommandLine getModulesCommand(File minicondaDownloadDest) {

		CommandLine unix = new CommandLine(CONDA_FOLDER + File.separator + "bin" + File.separator + "conda");
		unix.addArgument("install");
		unix.addArgument("scikit-learn");

		CommandLine windows = new CommandLine(CONDA_FOLDER + File.separator + "Scripts" + File.separator + "conda");
		windows.addArgument("install");
		windows.addArgument("scikit-learn");

		switch (version) {
		case WINDOWS32:
		case WINDOWS64:
			return windows;
		case MacOS:
		case LINUX32:
		case LINUX64:
			return unix;
		case UNKNOWN:
			return null;
		}

		return null;
	}

	/**
	 * different file extensions and names are required on different operating
	 * systems...
	 * 
	 * @return the file name with extension appropriate to the OS
	 */
	static File getDownloadDestination() {
		switch (version) {
		case WINDOWS32:
		case WINDOWS64:
			return new File(UTIL_FOLDER + File.separator + "minicondaInstall.exe");
		case MacOS:
		case LINUX32:
		case LINUX64:
			return new File(UTIL_FOLDER + File.separator + "minicondaInstall.sh");
		case UNKNOWN:
			return null;
		}
		return null;
	}

	/**
	 * The location of the download is different for different OS
	 * 
	 * @return a URL which contains the script to be downloaded which installs
	 *         miniconda
	 * @throws Exception
	 *             if the URL cant be found
	 */
	static URL getOSDownload() throws Exception {

		switch (version) {
		case MacOS:
			return new URL("https://repo.continuum.io/miniconda/Miniconda2-latest-MacOSX-x86_64.sh");
		case WINDOWS32:
			return new URL("https://repo.continuum.io/miniconda/Miniconda2-latest-Windows-x86.exe");
		case WINDOWS64:
			return new URL("https://repo.continuum.io/miniconda/Miniconda2-latest-Windows-x86_64.exe");
		case LINUX32:
			return new URL("https://repo.continuum.io/miniconda/Miniconda2-latest-Linux-x86.sh");
		case LINUX64:
			return new URL("https://repo.continuum.io/miniconda/Miniconda2-latest-Linux-x86_64.sh");
		case UNKNOWN:
			return null;
		}

		return null;
	}

	/**
	 * might have issues with different bit-versions of java installed on
	 * different OS (ex 32 bit java on 64 bit linux)
	 * 
	 * @return the OS version of the current machine
	 */
	private static OSVersion getOSVersion() {
		String os = System.getProperty("os.name");
		if (os.contains("Mac"))
			return OSVersion.MacOS;
		if (os.contains("Windows"))
			if (System.getenv("ProgramFiles(x86)") == null)
				return OSVersion.WINDOWS32;
			else
				return OSVersion.WINDOWS64;
		if (os.contains("Linux"))
			if (System.getProperty("os.arch").contains("64"))
				return OSVersion.LINUX64;
			else
				return OSVersion.LINUX32;

		return OSVersion.UNKNOWN;
	}

	/**
	 * possible different operating systems to be considered by pitype
	 * 
	 * @author mwrana
	 *
	 */
	private enum OSVersion {
		MacOS, WINDOWS32, WINDOWS64, LINUX32, LINUX64, UNKNOWN;
	}

	/**
	 * copies a zip file which contains the pitype python script into the utils
	 * folder created
	 * 
	 * @param classRef
	 *            reference to a class object contained within the jar
	 * @throws Exception
	 *             if the copying of files fails somehow
	 */
	static void copyPythonFiles(Object classRef) throws Exception {
		File piTypeDestination = new File(UTIL_FOLDER + File.separator + "Pitype2.zip");
		FileUtils.copyURLToFile(classRef.getClass().getClassLoader().getResource("Pitype2.zip"), piTypeDestination);
		extractZip(piTypeDestination.getAbsolutePath());
		piTypeDestination.delete();
	}

	/**
	 * Helper method which recursively extracts a zip file, and all the files
	 * within it
	 * 
	 * @param filename
	 * @throws Exception
	 */
	private static void extractZip(String filename) throws Exception {

		File srcFile = new File(filename);
		String zipPath = srcFile.getParent();
		File temp = new File(zipPath);
		temp.mkdir();
		ZipFile zipFile = null;
		zipFile = new ZipFile(srcFile);
		Enumeration<? extends ZipEntry> e = zipFile.entries();
		while (e.hasMoreElements()) {

			ZipEntry entry = e.nextElement();
			File destinationPath = new File(zipPath, entry.getName());
			destinationPath.getParentFile().mkdirs();
			if (entry.isDirectory())
				continue;
			else {

				BufferedInputStream bis = new BufferedInputStream(zipFile.getInputStream(entry));
				int b;
				byte buffer[] = new byte[1024];
				FileOutputStream fos = new FileOutputStream(destinationPath);
				BufferedOutputStream bos = new BufferedOutputStream(fos, 1024);
				while ((b = bis.read(buffer, 0, 1024)) != -1) {
					bos.write(buffer, 0, b);
				}
				bos.close();
				bis.close();
			}
		}
		zipFile.close();
	}

	/**
	 * a replacement for .contains() since 2 edges are not always equal, yet
	 * need to be removed if they have the same source and target nodes
	 * 
	 * @param edge
	 *            an edge that may or may not already be in a list
	 * @param edgeList
	 *            a list of Edges that may or may not contain a specfic edge
	 * @return true if the list contains the edge, false otherwise
	 */
	static boolean checkEdgePresence(CyEdge edge, ArrayList<CyEdge> edgeList) {
		for (CyEdge listEdge : edgeList) {
			if (listEdge.getSource().equals(edge.getSource()) && listEdge.getTarget().equals(edge.getTarget()))
				return true;
		}
		return false;
	}

}
