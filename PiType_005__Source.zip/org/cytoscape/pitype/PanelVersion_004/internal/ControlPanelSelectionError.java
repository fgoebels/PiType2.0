package org.cytoscape.pitype.PanelVersion_004.internal;

import javax.swing.JOptionPane;

public class ControlPanelSelectionError extends Exception {
	private static final long serialVersionUID = -6954028006449874611L;

	public ControlPanelSelectionError(String message) {
		super(message);
	}

	public void showUserErrorMessage() {
		JOptionPane.showMessageDialog(null, this.getMessage(), "PiType Error", JOptionPane.ERROR_MESSAGE);
	}

}
