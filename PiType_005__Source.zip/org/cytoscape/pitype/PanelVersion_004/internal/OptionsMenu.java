package org.cytoscape.pitype.PanelVersion_004.internal;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.HeadlessException;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.concurrent.ExecutionException;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JTextArea;
import javax.swing.SwingWorker;

import org.apache.commons.exec.CommandLine;
import org.apache.commons.exec.DefaultExecutor;
import org.apache.commons.io.FileUtils;

import org.cytoscape.pitype.PanelVersion_004.internal.PiTypeUtils.OSVersion;

/**
 * This class represents the menu which appears if the user has never installed
 * PiType before. It handles the first time installation and progress meter if
 * automatic is chosen, and the text input if custom is chosen
 * 
 * @author mwrana
 *
 */
public class OptionsMenu extends JFrame {

	private static final long serialVersionUID = -7281194053208476620L;

	private static final JLabel dialogLabel1 = new JLabel(
			"PiType has detected this is your first time running the App, and requires some setup.");
	private static final JLabel dialogLabel2 = new JLabel(
			"In order to run correctly, PiType needs to Install Miniconda with Python 2.7 onto your machine.");
	private static final JLabel dialogLabel3 = new JLabel(
			"If you would like to handle the download and installation automatically, select the 'Automatic' option (approximately 1.5 GB).");
	private static final JLabel dialogLabel4 = new JLabel(
			"If you already have Miniconda/Anaconda downloaded, or would like to use your own installation of python, select the 'Custom' option.");

	private static final JLabel customDialogLabel1 = new JLabel(
			"The PiType Classifier was built using Python 2.7 and 3 external libraries:");
	private static final JLabel customDialogLabel2 = new JLabel("NumPy, SciPy, and scikit-learn");
	private static final JLabel customDialogLabel3 = new JLabel(
			"Ensure you have an installation of python 2.7 with these modules.");
	private static final JLabel customDialogLabel4 = new JLabel(
			"Type the location of a python installation which meets these requirements below (press continue when done).");
	private final JTextArea customDialogInputArea = new JTextArea();

	private PiTypeControlPanel controlPanel;

	/**
	 * @param controlPanel
	 *            a reference to the control panel object from which the 'run'
	 *            button was pressed
	 * @throws HeadlessException
	 *             if the JFrame loses its reference or something (happens when
	 *             cytoscape quits)
	 */
	public OptionsMenu(PiTypeControlPanel controlPanel) throws HeadlessException {
		super();
		this.controlPanel = controlPanel;
		createOriginalGUI();
	}

	private void automaticInstall() {
		JLabel progressLabel = createAndShowAutomaticGUI();

		// Creating an instance of the installation task, and executing it
		AutomaticInstallTask automaticInstallTask = new AutomaticInstallTask(progressLabel, this);
		automaticInstallTask.execute();
	}

	private void customInstall() {
		JLabel progressLabel = createAndShowAutomaticGUI();
		setTitle("Custom Verification Progress");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setPreferredSize(new Dimension(450, 90));

		CustomInstallTask customInstallTask = new CustomInstallTask(progressLabel, this,
				customDialogInputArea.getText());
		customInstallTask.execute();
	}

	public JLabel createAndShowAutomaticGUI() {
		JLabel progressLabel = new JLabel("Initializing...");
		progressLabel.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 0));
		JProgressBar progressBar = new JProgressBar();
		progressBar.setIndeterminate(true);
		progressBar.setBorder(BorderFactory.createEmptyBorder(0, 10, 10, 10));

		setTitle("Automatic Install Progress");
		setPreferredSize(new Dimension(400, 90));
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		getContentPane().removeAll();
		getContentPane().add(progressLabel, BorderLayout.CENTER);
		getContentPane().add(progressBar, BorderLayout.SOUTH);
		pack();
		revalidate();
		repaint();

		return progressLabel;
	}

	public void createAndShowCustomGUI() {
		JPanel textPanel = new JPanel();
		textPanel.setLayout(new BoxLayout(textPanel, BoxLayout.Y_AXIS));
		customDialogLabel1.setAlignmentX(Component.CENTER_ALIGNMENT);
		customDialogLabel1.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
		textPanel.add(customDialogLabel1);
		customDialogLabel2.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
		customDialogLabel2.setAlignmentX(Component.CENTER_ALIGNMENT);
		customDialogLabel2.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 13));
		textPanel.add(customDialogLabel2);
		customDialogLabel3.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
		customDialogLabel3.setAlignmentX(Component.CENTER_ALIGNMENT);
		textPanel.add(customDialogLabel3);
		customDialogLabel4.setAlignmentX(Component.CENTER_ALIGNMENT);
		customDialogLabel4.setAlignmentX(Component.CENTER_ALIGNMENT);
		textPanel.add(customDialogLabel4);
		textPanel.add(Box.createVerticalStrut(12));
		textPanel.add(customDialogInputArea);
		customDialogInputArea.setLineWrap(true);
		customDialogInputArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));

		JPanel buttonPanel = new JPanel();
		JButton automaticButton = new JButton("Use Automatic Instead");
		buttonPanel.add(automaticButton);
		automaticButton.addActionListener(e -> automaticInstall());
		JButton continueButton = new JButton("Continue with Custom");
		buttonPanel.add(continueButton);
		continueButton.addActionListener(e -> customInstall());
		this.add(buttonPanel, BorderLayout.SOUTH);

		setTitle("Custom Install Information");
		setPreferredSize(new Dimension(650, 240));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().removeAll();
		getContentPane().add(textPanel, BorderLayout.CENTER);
		getContentPane().add(buttonPanel, BorderLayout.SOUTH);
		pack();
		revalidate();
		repaint();

	}

	public void createOriginalGUI() {
		
		JPanel mainOptionsPanel = new JPanel();
		mainOptionsPanel.setLayout(new BoxLayout(mainOptionsPanel, BoxLayout.PAGE_AXIS));
		// Header Label, which is Bold and larger than the rest, given border
		// above and below
		dialogLabel1.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		dialogLabel1.setAlignmentX(Component.CENTER_ALIGNMENT);
		dialogLabel1.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		mainOptionsPanel.add(dialogLabel1);
		// Additional Information Label, similarly given spacing
		dialogLabel2.setAlignmentX(Component.CENTER_ALIGNMENT);
		dialogLabel2.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		mainOptionsPanel.add(dialogLabel2);
		// The last 2 labels should be placed close to each other, as to appear
		// as a single statement, so they have no borders in between each other
		dialogLabel3.setAlignmentX(Component.CENTER_ALIGNMENT);
		mainOptionsPanel.add(dialogLabel3);
		dialogLabel4.setAlignmentX(Component.CENTER_ALIGNMENT);
		dialogLabel4.setBorder(BorderFactory.createEmptyBorder(0, 10, 10, 10));
		mainOptionsPanel.add(dialogLabel4);

		JPanel mainButtonsPanel = new JPanel();
		mainButtonsPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));

		JButton automaticInstallButton = new JButton("Automatic (Recommended)");
		JButton customInstallButton = new JButton("Custom");

		// Adding custom install button and action listener
		mainButtonsPanel.add(customInstallButton);
		customInstallButton.addActionListener(e -> createAndShowCustomGUI());
		// adding auto-install button and action listener
		mainButtonsPanel.add(automaticInstallButton);
		automaticInstallButton.addActionListener(e -> automaticInstall());
		
		this.getContentPane().removeAll();
		setTitle("PiType First Time Setup");
		setPreferredSize(new Dimension(900, 200));
		setLocationRelativeTo(null);
		setResizable(false);
		getContentPane().setLayout(new BorderLayout());
		getContentPane().add(mainOptionsPanel, BorderLayout.CENTER);
		getContentPane().add(mainButtonsPanel, BorderLayout.SOUTH);
		setAlwaysOnTop(true);
		pack();
		revalidate();
		repaint();
	}

	/**
	 * This class is a SwingWorker, which means it is designed to work in the
	 * background after the user presses a button. Using this class allows me to
	 * update the user on install progress without freezing the UI, while
	 * downloading and installing various things on users' computer
	 * 
	 * @author mwrana
	 *
	 */
	private class AutomaticInstallTask extends SwingWorker<Void, String> {

		private JLabel progressText;
		private OptionsMenu menu;
		private String pythonLocation;
		private OSVersion version;

		private AutomaticInstallTask(JLabel progressText, OptionsMenu menu) {
			// global variables
			this.progressText = progressText;
			this.menu = menu;
			this.version = PiTypeUtils.getOSVersion();
		}

		/**
		 * Sets the progressLabel created in automaticInstall() to represent the
		 * current install phase of PiType
		 */
		@Override
		protected void process(List<String> chunks) {
			for (String s : chunks) {
				progressText.setText(s);
			}
		}

		/**
		 * This is the 'main' method of AutomaticInstallTask and where most of
		 * the action happens, a little bit of setup and finishing is located
		 * elsewhere
		 */
		@Override
		protected Void doInBackground() throws Exception {

			// Creating and setting variables
			String homeDir = System.getProperty("user.home");
			File minicondaDownloadDest = new File(homeDir + File.separator + exeOrSh());
			DefaultExecutor executor = new DefaultExecutor();

			// get command to install miniconda, different depending on OS
			CommandLine installMiniCommand = getInstallCommand(minicondaDownloadDest, homeDir);
			if (installMiniCommand == null) {
				throw new Exception("PiType Only Supports Windows, MacOS, and Linux");
			}

			// command line which adds the external modules required by pitype
			// onto users machine

			CommandLine installModulesCommand = getModulesCommand(minicondaDownloadDest, homeDir);

			// Update user on progress
			publish("Initilization Complete ... Beginning Download");
			URL minicondaDownload = new URL(getOSDownload());

			// update user and download .sh file for install
			publish("Downloading Miniconda...");
			FileUtils.copyURLToFile(minicondaDownload, minicondaDownloadDest);

			// update user and begin installation of miniconda
			publish("Download Complete");
			Thread.sleep(1000);
			publish("Installing Miniconda...");
			executor.execute(installMiniCommand);

			// update user and begin installation of external modules
			publish("Install Complete.");
			Thread.sleep(1000);
			publish("Downloading & Installing Additional Libraries...");
			executor.execute(installModulesCommand);

			this.publish("Extracting Utility Files");
			Thread.sleep(1000);
			PiTypeUtils.copyPythonFiles(this.getClass().getClassLoader());

			// update user and exit try statement
			publish("Installation Complete... Finalizing");
			Thread.sleep(1000);

			minicondaDownloadDest.delete();

			/*
			 * set the python location, write it to the XML file, and proceed to
			 * done() where all the swing elements will be updated, since the
			 * script is now finished
			 */
			this.pythonLocation = homeDir + File.separator + "Miniconda_PiType" + File.separator + "bin"
					+ File.separator + "python";
			PiTypeUtils.updateXML(this, pythonLocation);

			return null;
		}

		/**
		 * Once the Install has completed, change the run button action
		 * listener, so it now runs PiType normally, instad of displaying this
		 * dialog, then close this dialog
		 */
		@Override
		public void done() {
			try {
				get();
			} catch (Exception e) {
				menu.setVisible(false);
				JOptionPane.showMessageDialog(null, e.getMessage(), "PiType Error", JOptionPane.ERROR_MESSAGE);
				menu.setVisible(true);
				return;
			} finally {
				createOriginalGUI();
			}
			JButton runButton = controlPanel.getRunButton();
			for (ActionListener al : runButton.getActionListeners())
				runButton.removeActionListener(al);
			runButton.addActionListener(e -> controlPanel.runEDT(controlPanel.getRunPanel(), pythonLocation));
			menu.dispose();
		}

		private String getOSDownload() {

			switch (version) {
			case MacOS:
				return "https://repo.continuum.io/miniconda/Miniconda2-latest-MacOSX-x86_64.sh";
			case WINDOWS32:
				return "https://repo.continuum.io/miniconda/Miniconda2-latest-Windows-x86.exe";
			case WINDOWS64:
				return "https://repo.continuum.io/miniconda/Miniconda2-latest-Windows-x86_64.exe";
			case LINUX32:
				return "https://repo.continuum.io/miniconda/Miniconda2-latest-Linux-x86.sh";
			case LINUX64:
				return "https://repo.continuum.io/miniconda/Miniconda2-latest-Linux-x86_64.sh";
			case UNKNOWN:
				return null;
			}

			return null;
		}

		private String exeOrSh() {
			switch (version) {
			case WINDOWS32:
			case WINDOWS64:
				return "minicondaInstall.exe";
			case MacOS:
			case LINUX32:
			case LINUX64:
				return "minicondaInstall.sh";
			case UNKNOWN:
				return null;
			}
			return null;
		}

		private CommandLine getInstallCommand(File downloadDest, String homeDir) {

			CommandLine installMiniCommandUnix = new CommandLine("/bin/bash");
			installMiniCommandUnix.addArgument(downloadDest.getAbsolutePath());
			installMiniCommandUnix.addArgument("-b");
			installMiniCommandUnix.addArgument("-p");
			installMiniCommandUnix.addArgument(homeDir + File.separator + "Miniconda_PiType");

			CommandLine installMiniCommandWindows = new CommandLine(downloadDest.getAbsolutePath());
			installMiniCommandWindows.addArgument("/S");
			installMiniCommandWindows.addArgument("/D=" + homeDir + File.separator + "Miniconda_PiType");

			switch (version) {
			case WINDOWS32:
			case WINDOWS64:
				return installMiniCommandWindows;
			case MacOS:
			case LINUX32:
			case LINUX64:
				return installMiniCommandUnix;
			case UNKNOWN:
				return null;
			}

			return null;
		}

		private CommandLine getModulesCommand(File minicondaDownloadDest, String homeDir) {
			CommandLine unix = new CommandLine(
					homeDir + File.separator + "Miniconda_PiType" + File.separator + "bin" + File.separator + "conda");
			unix.addArgument("install");
			unix.addArgument("scikit-learn");

			CommandLine windows = new CommandLine(homeDir + File.separator + "Miniconda_PiType" + File.separator
					+ "Scripts" + File.separator + "conda");
			windows.addArgument("install");
			windows.addArgument("scikit-learn");

			switch (version) {
			case WINDOWS32:
			case WINDOWS64:
				return windows;
			case MacOS:
			case LINUX32:
			case LINUX64:
				return unix;
			case UNKNOWN:
				return null;
			}

			return null;
		}

	}

	private class CustomInstallTask extends SwingWorker<Void, String> {

		private OptionsMenu menu;
		private String givenLocation;
		private JLabel progressText;

		public CustomInstallTask(JLabel progressText, OptionsMenu menu, String givenLocation) {
			this.menu = menu;
			this.givenLocation = givenLocation;
			this.progressText = progressText;
		}

		/**
		 * Sets the progressLabel created in automaticInstall() to represent the
		 * current install phase of PiType
		 */
		@Override
		protected void process(List<String> chunks) {
			for (String s : chunks) {
				progressText.setText(s);
			}
		}

		@Override
		protected Void doInBackground() throws Exception {

			this.publish("Ensuring File Has Correct Type");
			Thread.sleep(1000);

			File locationFile = new File(givenLocation);

			if (!locationFile.exists())
				throw new Exception("The file you specified does not exist");

			if (locationFile.isDirectory())
				throw new Exception(
						"The file you specified is a directory\n please select the python execution script");

			// Create the custom python tester file
			File customTester = new File(System.getProperty("user.home") + File.separator + "customTester.py");
			FileUtils.copyURLToFile(getClass().getClassLoader().getResource("customTester.py"), customTester);

			DefaultExecutor executor = new DefaultExecutor();
			CommandLine runScript = new CommandLine(givenLocation);
			runScript.addArgument(customTester.getAbsolutePath());

			this.publish("Ensuring correct python version and modules");
			Thread.sleep(1000);

			try {
				executor.execute(runScript);
			} catch (Exception e) {
				System.out.println(e.getMessage());
				throw new Exception(
						"It Appears Either your python version is NOT 2.7, or you are missing some modules.");
			} finally {
				customTester.delete();
			}

			this.publish("Extracting Utility Files");
			Thread.sleep(1000);
			PiTypeUtils.copyPythonFiles(this.getClass().getClassLoader());

			this.publish("Updating Configuration Files");
			Thread.sleep(1000);
			PiTypeUtils.updateXML(this, givenLocation);

			return null;
		}

		@Override
		public void done() {
			try {
				get();
			} catch (Exception e) {
				menu.setVisible(false);
				JOptionPane.showMessageDialog(null, e.getMessage(), "PiType Custom Install Error",
						JOptionPane.ERROR_MESSAGE);
				menu.setVisible(true);
				return;
			} finally {
				menu.createAndShowCustomGUI();
			}
			menu.setVisible(false);
			JOptionPane.showMessageDialog(null, "Custom Installation Verified, Press OK to Complete.",
					"PiType Confirmation", JOptionPane.INFORMATION_MESSAGE);
			JButton runButton = controlPanel.getRunButton();
			for (ActionListener al : runButton.getActionListeners())
				runButton.removeActionListener(al);
			runButton.addActionListener(e -> controlPanel.runEDT(controlPanel.getRunPanel(), givenLocation));
			menu.dispose();
		}

	}

}
