package org.cytoscape.pitype.PanelVersion_004.internal;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Paint;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.concurrent.ExecutionException;

import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;

import org.apache.commons.exec.CommandLine;
import org.apache.commons.exec.DefaultExecutor;
import org.cytoscape.application.CyApplicationManager;
import org.cytoscape.application.swing.CytoPanelComponent;
import org.cytoscape.application.swing.CytoPanelName;
import org.cytoscape.model.CyEdge;
import org.cytoscape.model.CyNetwork;
import org.cytoscape.model.CyNode;
import org.cytoscape.model.CyRow;
import org.cytoscape.model.CyTable;
import org.cytoscape.model.CyTableUtil;
import org.cytoscape.view.model.VisualProperty;
import org.cytoscape.view.presentation.property.BasicVisualLexicon;
import org.cytoscape.view.vizmap.VisualMappingFunctionFactory;
import org.cytoscape.view.vizmap.VisualMappingManager;
import org.cytoscape.view.vizmap.VisualStyle;
import org.cytoscape.view.vizmap.mappings.BoundaryRangeValues;
import org.cytoscape.view.vizmap.mappings.ContinuousMapping;
import org.cytoscape.view.vizmap.mappings.ContinuousMappingPoint;
import org.cytoscape.view.vizmap.mappings.DiscreteMapping;

public class PiTypeControlPanel extends JPanel implements CytoPanelComponent {

	private static final long serialVersionUID = -8809766310401404671L;
	private JButton runButton;
	private RunPanel mainPanel;
	private CyApplicationManager cyApplicationManager;
	private VisualMappingManager vmmServiceRef;
	private CyNetwork activeNetwork;
	private VisualMappingFunctionFactory vmFactoryC;
	private VisualMappingFunctionFactory vmFactoryD;

	public PiTypeControlPanel(CyApplicationManager cyApplicationManager, VisualMappingManager vmmServiceRef,
			VisualMappingFunctionFactory vmFactoryC, VisualMappingFunctionFactory vmFactoryD) {
		// Setting global variables
		this.cyApplicationManager = cyApplicationManager;
		this.vmmServiceRef = vmmServiceRef;
		this.vmFactoryC = vmFactoryC;
		this.vmFactoryD = vmFactoryD;

		// Adding Run button action listener
		mainPanel = new RunPanel();
		runButton = new JButton("Run");

		// Setting layout, adding elements, making visible to user
		this.setLayout(new BorderLayout());
		this.add(mainPanel, BorderLayout.CENTER);
		this.add(runButton, BorderLayout.SOUTH);
		this.setVisible(true);

		/*
		 * Reading XML File, if the location of Python has not been set, create
		 * the install script menu, and change the action upon pressing run to
		 * make this menu visible otherwise add the correct Action Listener to
		 * the run button
		 */
		String pythonLocation = PiTypeUtils.readXML(this);
		if (pythonLocation == null) {
			OptionsMenu menu = new OptionsMenu(this);
			runButton.addActionListener(e -> menu.setVisible(true));
		} else {
			runButton.addActionListener(e -> runEDT(mainPanel, pythonLocation));
		}
	}

	/**
	 * This Method is designed to get the user input, ensure it has been entered
	 * correctly, then run PiType. If the program has determined that python has
	 * not been installed, the run button will instead make the install menu
	 * visible
	 * 
	 * @param mainPanel
	 *            the JPanel which represents all the possible user input boxes
	 * @param pythonLocation
	 *            The location of users' python installation
	 */
	public void runEDT(RunPanel mainPanel, String pythonLocation) {

		this.activeNetwork = cyApplicationManager.getCurrentNetwork();
		JFrame progressBarFrame = new JFrame("PiType progress");

		JLabel progressLabel = new JLabel("Initializing...");
		progressLabel.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 0));
		JProgressBar progressBar = new JProgressBar();
		progressBar.setIndeterminate(true);
		progressBar.setBorder(BorderFactory.createEmptyBorder(0, 10, 10, 10));

		progressBarFrame.setTitle("Automatic Install Progress");
		progressBarFrame.setPreferredSize(new Dimension(400, 90));
		progressBarFrame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		progressBarFrame.setResizable(false);
		progressBarFrame.setLocationRelativeTo(null);
		progressBarFrame.getContentPane().removeAll();
		progressBarFrame.getContentPane().add(progressLabel, BorderLayout.CENTER);
		progressBarFrame.getContentPane().add(progressBar, BorderLayout.SOUTH);
		progressBarFrame.pack();
		progressBarFrame.setVisible(true);

		PiTypeTask pitypeTask = new PiTypeTask(progressLabel, progressBarFrame, pythonLocation);
		pitypeTask.execute();
	}

	private class PiTypeTask extends SwingWorker<Void, String> {

		private JLabel progressText;
		private JFrame progressBarFrame;
		private String pythonLocation;

		private PiTypeTask(JLabel progressLabel, JFrame progressBarFrame, String pythonLocation) {
			this.progressText = progressLabel;
			this.progressBarFrame = progressBarFrame;
			this.pythonLocation = pythonLocation;

		}

		@Override
		protected void process(List<String> chunks) {
			for (String chunk : chunks) {
				progressText.setText(chunk);
			}
		}

		@Override
		protected Void doInBackground() throws Exception {

			int edgeSelection = 0;
			String featureSelection = null;
			int taxonomy;
			try {
				edgeSelection = mainPanel.getEdgeSelection();
				featureSelection = mainPanel.getFeatureSelection();
				taxonomy = mainPanel.getTaxonomySelection();
			} catch (ControlPanelSelectionError e) {
				e.showUserErrorMessage();
				return null;
			}

			publish("Getting EdgeList");
			List<CyEdge> selectedEdges = CyTableUtil.getEdgesInState(activeNetwork, "selected", true);

			if (edgeSelection == 1 && selectedEdges.size() == 0) {
				new ControlPanelSelectionError("No edges Selected\nSelect at least one edge and re-run")
						.showUserErrorMessage();
				progressBarFrame.dispose();
				return null;
			}

			if (edgeSelection == 0)
				selectedEdges.addAll(CyTableUtil.getEdgesInState(activeNetwork, "selected", false));

			HashSet<CyEdge> temp = new HashSet<CyEdge>();
			temp.addAll(selectedEdges);
			selectedEdges.clear();
			selectedEdges.addAll(temp);
			Thread.sleep(1000);

			String scriptLocation = System.getProperty("user.home") + File.separator + "PiTypeUtils";

			// writing the node data to a text file, for PiType to analyze
			publish("Writing Node Data to File");
			PiTypeUtils.writeNodeData(activeNetwork, selectedEdges);
			Thread.sleep(1000);

			// python_location,python_file,features,taxID,input_file,output_file

			publish("Generating Command Line");
			Thread.sleep(1000);
			CommandLine startPitype = new CommandLine(pythonLocation);
			startPitype.addArgument(scriptLocation + File.separator + "Pitype2.py");
			startPitype.addArgument(featureSelection);
			startPitype.addArgument(String.valueOf(taxonomy));
			startPitype.addArgument(scriptLocation + File.separator + "input.txt");
			startPitype.addArgument(scriptLocation + File.separator + "output.txt");

			publish("Classifying -- (Estimated 000 minutes)");
			DefaultExecutor executor = new DefaultExecutor();
			executor.execute(startPitype);

			publish("Updating Table and applying Gradient");
			Thread.sleep(1000);
			CyTable edgeTable = activeNetwork.getDefaultEdgeTable();
			if (edgeTable.getColumn("pitype_score") != null)
				edgeTable.deleteColumn("pitype_score");
			if (edgeTable.getColumn("pitype_classification") != null)
				edgeTable.deleteColumn("pitype_classification");
			edgeTable.createColumn("pitype_score", Double.class, true, 0.0);
			edgeTable.createColumn("pitype_classification", String.class, true, "--");

			List<CyRow> edgeRows = edgeTable.getAllRows();
			BufferedReader buff = new BufferedReader(new FileReader(scriptLocation + File.separator + "output.txt"));
			String line;
			while ((line = buff.readLine()) != null) {
				String[] lineData = line.split("\t");
				for (CyRow edge : edgeRows) {
					String edgeName = edge.get("shared name", String.class);
					if (edgeName.contains(lineData[0]) && edgeName.contains(lineData[1])) {
						String classification;
						if (Integer.valueOf(lineData[2]) == 0)
							classification = "nob";
						else
							classification = "ob";
						edge.set("pitype_classification", classification);
						edge.set("pitype_score", Double.valueOf(lineData[3]));

					}
				}
			}
			buff.close();

			SwingUtilities.invokeAndWait(new Runnable() {
				@Override
				public void run() {
					ContinuousMapping<Double, Double> cMapping = (ContinuousMapping<Double, Double>) vmFactoryC
							.createVisualMappingFunction("pitype_score", Double.class, BasicVisualLexicon.EDGE_WIDTH);

					DiscreteMapping<String, Paint> dMapping = (DiscreteMapping<String, Paint>) vmFactoryD
							.createVisualMappingFunction("pitype_classification", String.class,
									BasicVisualLexicon.EDGE_STROKE_UNSELECTED_PAINT);
					
					dMapping.putMapValue("nob", Color.BLUE);
					dMapping.putMapValue("ob", Color.GREEN);
					
					BoundaryRangeValues<Double> brv1 = new BoundaryRangeValues<Double>(5.0, 5.0, 5.0);
					BoundaryRangeValues<Double> brv2 = new BoundaryRangeValues<Double>(0.0, 0.0, 0.0);
					cMapping.addPoint(0.0, brv1);
					cMapping.addPoint(0.5, brv2);
					cMapping.addPoint(1.0, brv1);

					VisualStyle vs = vmmServiceRef.getCurrentVisualStyle();
					vs.addVisualMappingFunction(cMapping);
					vs.addVisualMappingFunction(dMapping);
					vmmServiceRef.setCurrentVisualStyle(vs);
				}
			});

			publish("Done...Finalizing");
			Thread.sleep(1000);

			return null;
		}

		@Override
		public void done() {
			try {
				this.get();
			} catch (Exception e) {
				progressBarFrame.setVisible(false);
				JOptionPane.showMessageDialog(null, e.getMessage(), "PiType Error", JOptionPane.ERROR_MESSAGE);
				progressBarFrame.setVisible(true);
				e.printStackTrace();
				return;
			} finally {
				progressBarFrame.dispose();
			}

		}

	}

	public JButton getRunButton() {
		return this.runButton;
	}

	public RunPanel getRunPanel() {
		return this.mainPanel;
	}

	@Override
	public Component getComponent() {
		return this;
	}

	@Override
	public CytoPanelName getCytoPanelName() {
		return CytoPanelName.WEST;
	}

	@Override
	public String getTitle() {
		return "PiType";
	}

	@Override
	public Icon getIcon() {
		return null;
	}
}
