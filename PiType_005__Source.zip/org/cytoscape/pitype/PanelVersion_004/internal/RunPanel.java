package org.cytoscape.pitype.PanelVersion_004.internal;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;

import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.InputMap;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.BadLocationException;

/**
 * This class represents the panel which the user sees in the left menu of
 * Cytoscape above the run button. It contains text information about what
 * should be displayed, as well as references to all the radio buttons and check
 * boxes in the panel. It also contains helper methods for retrieving relevant
 * information from this menu
 * 
 * @author mwrana
 *
 */
public class RunPanel extends JPanel implements DocumentListener {

	private static final long serialVersionUID = -7404389217476648860L;
	private final JLabel selectionOptionsLabel = new JLabel("Edge Selection Options");
	private final ButtonGroup selectionOptionsGroup = new ButtonGroup();
	private final JRadioButton selectionOptionsAll = new JRadioButton("All Edges");
	private final JRadioButton selectionOptionsSelected = new JRadioButton("Selected Edges");

	private final JLabel featureSelectionLabel = new JLabel("Feature Selection");
	private final JCheckBox featureSelectionELMs = new JCheckBox("ELMs");
	private final JCheckBox featureSelectionDegree = new JCheckBox("Degree");
	private final JCheckBox featureSelectionString = new JCheckBox("String");
	private final JCheckBox featureSelectionGosim = new JCheckBox("GoSim");

	private final JLabel taxonomySelectionLabel = new JLabel("Taxonomy");
	private final JTextField taxonomySelection = new JTextField();
	private static final String COMMIT_STRING = "commit";

	private static enum CompletionMode {
		INSERT, COMPLETION
	};

	HashMap<String, Integer> taxonomiesMap;
	private CompletionMode mode = CompletionMode.COMPLETION;

	/**
	 * Creates a new RunPanel and adds all the labels and checkboxes to it, etc
	 */
	public RunPanel() {
		super();
		this.setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
		createAndShowGUI();

		try {
			ObjectInputStream ois = new ObjectInputStream(
					getClass().getClassLoader().getResource("speciesList.ser").openStream());
			taxonomiesMap = (HashMap<String, Integer>) ois.readObject();
			ois.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		taxonomySelection.setFocusTraversalKeysEnabled(false);
		taxonomySelection.getDocument().addDocumentListener(this);
		InputMap input = taxonomySelection.getInputMap();
		ActionMap action = taxonomySelection.getActionMap();
		input.put(KeyStroke.getKeyStroke("TAB"), COMMIT_STRING);
		action.put(COMMIT_STRING, new CommitAction());

	}

	/**
	 * This method determines if the user wants to analyze all the edges in
	 * their network, or only a select few
	 * 
	 * @return 0 for all, 1 for selected only
	 * @throws ControlPanelSelectionError
	 */
	int getEdgeSelection() throws ControlPanelSelectionError {
		if (this.selectionOptionsGroup.getSelection().getActionCommand().equals("all"))
			return 0;
		else if (this.selectionOptionsGroup.getSelection().getActionCommand().equals("selected"))
			return 1;
		throw new ControlPanelSelectionError(
				"It appears you have not selected whether you want to analyze all edges or selected edges."
						+ "\nPlease re-select an option and re-run");
	}

	/**
	 * This method determines which of the features the user would like to use
	 * when running putype
	 * 
	 * @return a boolean array representing the selection state of each checkbox
	 *         at the current time
	 * @throws ControlPanelSelectionError
	 */
	String getFeatureSelection() throws ControlPanelSelectionError {
		int[] returnVals = new int[4];
		returnVals[0] = (this.featureSelectionELMs.isSelected()) ? 1 : 0;
		returnVals[1] = (this.featureSelectionDegree.isSelected()) ? 1 : 0;
		returnVals[2] = (this.featureSelectionString.isSelected()) ? 1 : 0;
		returnVals[3] = (this.featureSelectionGosim.isSelected()) ? 1 : 0;

		if (containsTrue(returnVals))
			return String.valueOf(returnVals[0]) + String.valueOf(returnVals[1]) + String.valueOf(returnVals[2])
					+ String.valueOf(returnVals[3]);
		else
			throw new ControlPanelSelectionError(
					"It appears you have not selected any features.\nSelect at least one feature and re-run");

	}

	int getTaxonomySelection() throws ControlPanelSelectionError {
		String taxonomyEntered = taxonomySelection.getText();
		Integer taxonomyValue = taxonomiesMap.get(taxonomySelection.getText());
		if (taxonomyEntered == "")
			throw new ControlPanelSelectionError("Taxonomy Field is Empty.\nEnter a taxonomy and re-run.");
		else if (taxonomyValue != null)
			return taxonomyValue;
		else if (this.featureSelectionString.isSelected())
			throw new ControlPanelSelectionError(
					"The taxonomy entered does not exist in String.\nSee https://string-db.org/ for more info.\nIt might be recognized if Pitype is run without the 'String' feature.");
		else
			throw new ControlPanelSelectionError(
					"It appears the taxonomy entered does not exist.\nIf you are sure it does, it is not supported by PiType.");
	}

	/**
	 * helper method for false-only boolean arrays
	 * 
	 * @param array
	 *            a boolean array
	 * @return true if the array contains at least one true value, false
	 *         otherwise
	 */
	private boolean containsTrue(int[] array) {
		for (int val : array)
			if (val == 1)
				return true;
		return false;
	}

	private void createAndShowGUI() {

		selectionOptionsLabel.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
		featureSelectionLabel.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
		taxonomySelectionLabel.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));

		// Setting up JRadioButton Group
		selectionOptionsAll.setActionCommand("all");
		selectionOptionsAll.setSelected(true);
		selectionOptionsSelected.setActionCommand("selected");
		selectionOptionsGroup.add(selectionOptionsAll);
		selectionOptionsGroup.add(selectionOptionsSelected);

		// adding elements to JPanel
		add(selectionOptionsLabel, Component.LEFT_ALIGNMENT);
		add(Box.createVerticalStrut(5));
		add(selectionOptionsAll, Component.LEFT_ALIGNMENT);
		add(selectionOptionsSelected, Component.LEFT_ALIGNMENT);
		add(Box.createVerticalStrut(20));

		add(featureSelectionLabel, Component.LEFT_ALIGNMENT);
		add(Box.createVerticalStrut(5));
		add(featureSelectionELMs, Component.LEFT_ALIGNMENT);
		add(featureSelectionDegree, Component.LEFT_ALIGNMENT);
		add(featureSelectionString, Component.LEFT_ALIGNMENT);
		add(featureSelectionGosim, Component.LEFT_ALIGNMENT);
		add(Box.createVerticalStrut(20));

		add(taxonomySelectionLabel, Component.LEFT_ALIGNMENT);
		add(Box.createVerticalStrut(10));
		add(taxonomySelection);
		taxonomySelection.setMaximumSize(
				new Dimension(Integer.MAX_VALUE, (int) Math.round(taxonomySelection.getPreferredSize().getHeight())));
	}

	@Override
	public void insertUpdate(DocumentEvent e) {
		if (e.getLength() != 1)
			return;

		int pos = e.getOffset();
		String content = null;
		try {
			content = this.taxonomySelection.getText(0, pos + 1);
		} catch (BadLocationException ex) {
			ex.printStackTrace();
		}

		// Too few chars
		if (pos < 2)
			return;

		/*
		 * IN A HASHMAP YOU WILL SEACH FOR THE *FIRST* KEY WHICH MATCHES THE
		 * ENTERED TEXT AND DISPLAY THE REST OF THE KEY
		 */

		String prefix = content.substring(0).toLowerCase();

		if (taxonomiesMap.get(prefix) == null) {
			Iterator<Entry<String, Integer>> it = taxonomiesMap.entrySet().iterator();
			while (it.hasNext()) {
				String match = it.next().getKey();
				if (match.toLowerCase().startsWith(prefix)) {
					String completion = match.substring(pos + 1);
					SwingUtilities.invokeLater(new CompleteWordTask(completion, pos + 1));
					return;
				}
			}
			mode = CompletionMode.INSERT;
		}
	}

	@Override
	public void removeUpdate(DocumentEvent e) {
		// Do Nothing
	}

	@Override
	public void changedUpdate(DocumentEvent e) {
		// Do Nothing
	}

	private class CompleteWordTask implements Runnable {
		private String completion;
		private int position;

		CompleteWordTask(String completion, int position) {
			this.completion = completion;
			this.position = position;
		}

		@Override
		public void run() {
			StringBuffer buffer = new StringBuffer(taxonomySelection.getText());
			buffer.insert(position, completion);
			taxonomySelection.setText(buffer.toString());
			taxonomySelection.setCaretPosition(position + completion.length());
			taxonomySelection.moveCaretPosition(position);
			mode = CompletionMode.COMPLETION;

		}

	}

	private class CommitAction extends AbstractAction {
		private static final long serialVersionUID = -7613074872428990626L;

		@Override
		public void actionPerformed(ActionEvent ev) {
			if (mode == CompletionMode.COMPLETION) {
				int pos = taxonomySelection.getSelectionEnd();
				taxonomySelection.setCaretPosition(pos);
				mode = CompletionMode.INSERT;
			} else {
				taxonomySelection.replaceSelection("\t");
			}
		}
	}
}
