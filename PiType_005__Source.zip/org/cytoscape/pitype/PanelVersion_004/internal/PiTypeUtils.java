package org.cytoscape.pitype.PanelVersion_004.internal;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.Map.Entry;

import javax.swing.JOptionPane;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.exec.CommandLine;
import org.apache.commons.exec.DefaultExecutor;
import org.apache.commons.exec.ExecuteException;
import org.apache.commons.io.FileUtils;
import org.cytoscape.model.CyEdge;
import org.cytoscape.model.CyNetwork;
import org.cytoscape.model.CyNode;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

/**
 * static utility class for PiType, in order to keep the code from getting too
 * messy
 */
public class PiTypeUtils {

	/**
	 * This method reads the installConfig.xml file stored within the Jar of
	 * PiType
	 * 
	 * @return null, if a python installation has not been found previously, its
	 *         location if one has
	 */
	public static String readXML(Object classRef) {

		/*
		 * create a Document object which references the currently existing XML
		 * file in the jar
		 */
		Document doc = null;
		try {
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			doc = docBuilder.parse(classRef.getClass().getClassLoader().getResourceAsStream("installConfig.xml"));
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// return the python directory, if python has been correctly installed
		if (Boolean.parseBoolean(doc.getElementsByTagName("Installed").item(0).getTextContent()))
			return doc.getElementsByTagName("Directory").item(0).getTextContent();

		/*
		 * If a miniconda installation already exists in the location it is
		 * installed by pitype, with the name pitype installs it with, delete it
		 * as it might be outdated or corrupted due to error during install
		 */
		File potentialInstallation = new File(System.getProperty("user.home") + File.separator + "Miniconda_PiType");
		if (potentialInstallation.exists())
			try {
				FileUtils.deleteDirectory(potentialInstallation);
			} catch (IOException e) {
				e.printStackTrace();
			}

		return null;

	}

	/**
	 * This method updates the installConfig.xml file in PiType's .jar file, the
	 * updates to the xml file don't appear until Cytoscape has restarted
	 * typically. This method should only be run when a proper installation has
	 * been confirmed, since it does not check itself, only writes the given
	 * value.
	 * 
	 * @param classRef
	 *            a reference to a class within the PiType's jar file
	 * @param installLocation
	 *            the python install location, to be written to the XMl file
	 */
	public static void updateXML(Object classRef, String installLocation) {

		/*
		 * First create a Document object which references the currently
		 * existing XML file in the jar
		 */
		Document doc = null;
		try {
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			doc = docBuilder.parse(classRef.getClass().getClassLoader().getResourceAsStream("installConfig.xml"));
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		}

		// update the document reference with new values
		doc.getElementsByTagName("Installed").item(0).setTextContent("true");
		doc.getElementsByTagName("Directory").item(0).setTextContent(installLocation);

		TransformerFactory transFactory = TransformerFactory.newInstance();

		try {

			/*
			 * this mess basically creates a new xml file with all the content
			 * of the old one, but with the new values added above
			 */
			Transformer trans = transFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
			File tempStorage = new File(System.getProperty("user.home") + File.separator + "installConfig.xml");
			StreamResult result = new StreamResult(tempStorage);
			trans.transform(source, result);

			/*
			 * updates the jar file with the new xml file created above. this
			 * has to be done using console commands, as a running jar file
			 * cannot modify itself easily
			 */
			DefaultExecutor executor = new DefaultExecutor();

			CommandLine updateJar = new CommandLine("jar");
			updateJar.addArgument("uf");
			updateJar.addArgument(
					classRef.getClass().getProtectionDomain().getCodeSource().getLocation().toURI().getPath());
			updateJar.addArgument("-C");
			updateJar.addArgument(System.getProperty("user.home") + File.separator);
			updateJar.addArgument("installConfig.xml");

			executor.execute(updateJar);
			// delete temp files
			tempStorage.delete();
		} catch (TransformerConfigurationException e) {
			e.printStackTrace();
		} catch (TransformerException e) {
			e.printStackTrace();
		} catch (URISyntaxException e) {
			e.printStackTrace();
		} catch (ExecuteException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Maps a CyNode which is part of a list to its degree, which is the number
	 * of connecting nodes. Unnecessarily complicated since if there are
	 * multiple edges connecting the same 2 nodes, each edge counts as one
	 * adjacent node by cytoscape, but PiTyoe would count it as a single
	 * adjacent node
	 * 
	 * @param activeNetwork
	 *            a CyNetwork object which represents the network containing the
	 *            edges to be analyzeds
	 * @param selectedEdges
	 *            a list of CyEdges to be analyzed
	 * @param nodeType
	 *            either 0 for source nodes, or 1 for target nodes, since both
	 *            cannot be calculated simeltaneously, due to the limitations of
	 *            Java return types
	 * @return a LinkedHashMap of each Node mapped to its degree (excluding
	 *         repeat edges)
	 */
	public static LinkedHashMap<CyNode, Integer> getNodeData(CyNetwork activeNetwork, List<CyEdge> selectedEdges,
			int nodeType) {
		LinkedHashMap<CyNode, Integer> nodes = new LinkedHashMap<CyNode, Integer>();

		// Check whether analysis is for source or target nodes
		if (nodeType == 0)
			/*
			 * Get the source node for each edge in the list, get the number of
			 * adjacent edges, and put this into the nodes HashMap
			 */
			for (CyEdge edge : selectedEdges) {
				CyNode n = edge.getSource();
				List<CyNode> nodeList = activeNetwork.getNeighborList(n, CyEdge.Type.ANY);
				Set<CyNode> nodeSet = new HashSet<>();
				nodeSet.addAll(nodeList);
				nodes.put(n, nodeSet.size());
			}
		else
			// Same as above, for target nodes
			for (CyEdge edge : selectedEdges) {
				CyNode n = edge.getTarget();
				List<CyNode> nodeList = activeNetwork.getNeighborList(n, CyEdge.Type.ANY);
				Set<CyNode> nodeSet = new HashSet<>();
				nodeSet.addAll(nodeList);
				nodes.put(n, nodeSet.size());
			}
		return nodes;
	}

	/**
	 * This methods write the node data gathered from the above method
	 * getNodeData to a text file, which is then read by the PiType python
	 * script
	 * 
	 * @param activeNetwork
	 *            the CyNetwork which contains the source and target nodes in
	 *            the hasmap
	 * @param sourceNodes
	 *            A LinkedHashMap containing each source node and its degree
	 * @param targetNodes
	 *            a LinkedHashMap containing each target node and its degree
	 * @throws IOException
	 *             if an error occurs while writing the file, throws error
	 */
	public static void writeNodeData(CyNetwork activeNetwork, List<CyEdge> edgeList) throws IOException {

		// Creating (and establishing) Files & Iterators
		File writeLocation = new File(
				System.getProperty("user.home") + File.separator + "PiTypeUtils" + File.separator + "input.txt");
		Iterator<CyEdge> edgeIterator = edgeList.iterator();
		BufferedWriter fileWriter = null;

		try {
			// Assign the BufferedWriter to create the text file
			fileWriter = new BufferedWriter(new FileWriter(writeLocation));

			// source and target HashMaps have the same length, this works
			while (edgeIterator.hasNext()) {
				CyEdge edge = edgeIterator.next();
				CyNode source = edge.getSource();
				CyNode target = edge.getTarget();

				String sourceName = activeNetwork.getRow(source).get(CyNetwork.NAME, String.class);
				String targetName = activeNetwork.getRow(target).get(CyNetwork.NAME, String.class);

				fileWriter.write(sourceName + "\t" + targetName);
				fileWriter.newLine();
			}
		} catch (IOException ioe) {
			// send the error back to main runtime, so it doesnt attempt to
			// continue
			throw new IOException("Error occured while trying to write a file to the following location: "
					+ writeLocation.getAbsolutePath());
		} finally {
			// cleanup after sending error up callstack
			try {
				fileWriter.close();
			} catch (IOException ioe) {
				JOptionPane.showMessageDialog(null, "Unknown Error Occured:\n" + ioe.getMessage(), "PiType Error",
						JOptionPane.ERROR_MESSAGE);
				writeLocation.delete();
			}
		}

	}

	public void test() {
	}

	public static OSVersion getOSVersion() {
		String os = System.getProperty("os.name");
		if (os.contains("Mac"))
			return OSVersion.MacOS;
		if (os.contains("Windows"))
			if (System.getenv("ProgramFiles(x86)") == null)
				return OSVersion.WINDOWS32;
			else
				return OSVersion.WINDOWS64;
		if (os.contains("Linux"))
			if (System.getProperty("os.arch").contains("64"))
				return OSVersion.LINUX64;
			else
				return OSVersion.LINUX32;

		return OSVersion.UNKNOWN;
	}

	public enum OSVersion {
		MacOS, WINDOWS32, WINDOWS64, LINUX32, LINUX64, UNKNOWN;
	}

	public static String copyPythonFiles(ClassLoader classLoader) throws Exception {
		String home = System.getProperty("user.home");

		File piTypeDestination = new File(home + File.separator + "PiTypeUtils");

		if (piTypeDestination.exists())
			FileUtils.deleteDirectory(piTypeDestination);

		piTypeDestination.mkdirs();
		File piTypeDestinationZip = new File(piTypeDestination + File.separator + "Pitype2.zip");
		FileUtils.copyURLToFile(classLoader.getResource("Pitype2.zip"), piTypeDestinationZip);
		extractZip(piTypeDestinationZip.getAbsolutePath());
		piTypeDestinationZip.delete();

		return piTypeDestination + File.separator + "Pitype2.py";
	}

	private static void extractZip(String filename) throws Exception {

		File srcFile = new File(filename);

		// create a directory with the same name to which the contents will be
		// extracted
		String zipPath = srcFile.getParent();
		File temp = new File(zipPath);
		temp.mkdir();

		ZipFile zipFile = null;

		zipFile = new ZipFile(srcFile);

		// get an enumeration of the ZIP file entries
		Enumeration<? extends ZipEntry> e = zipFile.entries();

		while (e.hasMoreElements()) {

			ZipEntry entry = e.nextElement();

			File destinationPath = new File(zipPath, entry.getName());

			// create parent directories
			destinationPath.getParentFile().mkdirs();

			// if the entry is a file extract it
			if (entry.isDirectory())
				continue;
			else {

				BufferedInputStream bis = new BufferedInputStream(zipFile.getInputStream(entry));

				int b;
				byte buffer[] = new byte[1024];

				FileOutputStream fos = new FileOutputStream(destinationPath);

				BufferedOutputStream bos = new BufferedOutputStream(fos, 1024);

				while ((b = bis.read(buffer, 0, 1024)) != -1) {
					bos.write(buffer, 0, b);
				}

				bos.close();
				bis.close();

			}

		}

	}

}
